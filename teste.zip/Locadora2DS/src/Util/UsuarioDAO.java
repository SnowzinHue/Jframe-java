/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Util;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class UsuarioDAO {
    public void VerificarUsuario(String login, String senha) {
        if ((senha.equals("123456")) && login.equals("aulads")){
          JOptionPane.showMessageDialog(null, "Usuário correto. Bem vindo ao sistema!"); 
        } else {
            JOptionPane.showMessageDialog(null, "Usuário incorreto"); 
        
       }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author aluno
 */
public class Usuario {
    private static String login;
    private static String password;
    
    public Usuario (String login, String password){
         setLogin(login);
         setSenha(password);
    }
    
    public String getlogin (String login) {
        return login;
    }
    public void setLogin(String login) {
        this.login = login;
    }
            
    public String getSenha(String senha) {
        return senha;
    }
    
            
    public void setSenha(String senha){
        this.password = senha;
    }
            
              
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Util;
import javax.swing.JOptionPane;
import Telas.Login;
import Telas.Main;


/**
 *
 * @author aluno
 */
public class UsuarioDAO {

    /**
     *
     * @param login
     * @param senha
     * @return
     */
    public boolean VerificarUsuario(String login, String senha) {
        if ((senha.equals("123456")) && login.equals("aulads")){
            JOptionPane.showMessageDialog(null, "Usuário correto. Bem vindo ao sistema!");
            return true;
            
        } else {
            JOptionPane.showMessageDialog(null, "Usuário incorreto");
            return false;
        }
    }
}

import java.util.Scanner;

package javads;


public class JavaDS {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
    
}



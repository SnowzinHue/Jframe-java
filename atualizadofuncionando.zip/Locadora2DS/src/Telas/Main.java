/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Telas;

import javax.swing.JFrame;

/**
 *
 * @author aluno
 */
public class Main {

 

    public static void main(String[] args) {
        JFrame Login = new Login(); //Chama a janela LOGIN
        Login.setVisible(true);
    }
    
}
    /**
     * @param args the command line arguments
     */
    
        // TODO code application logic here
    
    

